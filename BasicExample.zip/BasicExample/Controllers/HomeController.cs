﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BasicExample.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
      
        public ActionResult Index()
        {
            TempData.Keep();
            float p = 25000, r = 2, t = 2;
            float si = (p * r * t) / 100;
            ViewBag.data = "Result is " + si + " "+ TempData["msg"];
            ViewBag.p = p;
            ViewData["p"] = p;
            return View();  // to load view file and default view index.cshtml
        }

    }
}
