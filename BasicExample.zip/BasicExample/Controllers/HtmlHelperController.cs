﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using BasicExample.Models;
namespace BasicExample.Controllers
{
    public class HtmlHelperController : Controller
    {
        //
        // GET: /HtmlHelper/

        public ActionResult Index()
        {
            return View();
        }
        void FillDDL()
        {
            List<SelectListItem> obj = new List<SelectListItem>();
            obj.Add(new SelectListItem() { Text = "INDIA", Value = "1001" });
            obj.Add(new SelectListItem() { Text = "USA", Value = "1002" });
            obj.Add(new SelectListItem() { Text = "CHINA", Value = "1003" });
            ViewBag.Country = obj;
        }
        public ActionResult StandaradHelper()
        {
            FillDDL();

            return View();
        }
        [HttpPost]
        public ActionResult StandaradHelper(FormCollection obj)
        {

            String name = obj["txt1"];
            String course = obj["course"];
            var  c = obj["basic[]"];
            StringBuilder sb = new StringBuilder();
            if (obj["basic1"].ToString().Contains("true"))
            {
                sb.Append("C");
            }
            if (obj["basic2"].ToString().Contains("true"))
            {
                sb.Append("CPP");
            }
            ViewBag.data = "Name is " + name + "Course is " + course + "Courses is " + sb.ToString() + " " + "Country is " + obj["Country"];
            FillDDL();
            return View();
        }
        void FillCourse()
        {
            List<SelectListItem> obj = new List<SelectListItem>();
            obj.Add(new SelectListItem() { Text = "Java", Value = "1001" });
            obj.Add(new SelectListItem() { Text = "C#", Value = "1002" });
            obj.Add(new SelectListItem() { Text = "PYTHON", Value = "1003" });
            ViewBag.CourseName = obj;
        }
        public ActionResult StronglyTyped()
        {
            FillCourse();
            return View();
        }
        [HttpPost]
        public ActionResult StronglyTyped(Enquiry o)
        {

         ///   ViewBag.Msg = "Enquiry Id " + o.EnqId + "Fullname is " + o.FirstName + " Course name is " + o.CourseName + "Gender is " + o.Gender; ;
             FillCourse();  
             TempData["Msg"] = "Enquiry Id " + o.EnqId + "Fullname is " + o.FirstName + " Course name is " + o.CourseName + "Gender is " + o.Gender; ;
             TempData.Keep();
            
             return RedirectToAction("Index","Home");
        }

    }
}
